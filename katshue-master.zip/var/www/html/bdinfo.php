<?php 
	define('SERVER', 'sqldbforweb.cuc0twrqljlf.us-west-2.rds.amazonaws.com');
	define('USER', 'foo');
	define('PASSWORD', 'barbarbar');
	define('DBNAME', 'mydb');
?>